"""
Credit Card Fraud Detection - educational machine-learning demo.

IMPORTANT:
- This project uses a SYNTHETIC demonstration dataset, not real bank transactions.
- Its metrics are for learning/testing only and must not be used for real fraud decisions.
"""

from pathlib import Path
import json
import joblib
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    classification_report, confusion_matrix, roc_auc_score,
    ConfusionMatrixDisplay
)

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "creditcard_transactions_demo.csv"
OUTPUT_DIR = ROOT / "outputs"
MODEL_PATH = OUTPUT_DIR / "fraud_detection_model.joblib"


def main():
    OUTPUT_DIR.mkdir(exist_ok=True)
    data = pd.read_csv(DATA_PATH)

    if "Class" not in data.columns:
        raise ValueError("Dataset must contain a 'Class' target column.")

    X = data.drop(columns=["Class"])
    y = data["Class"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )

    model = RandomForestClassifier(
        n_estimators=200,
        class_weight="balanced",
        random_state=42,
        n_jobs=-1
    )
    model.fit(X_train, y_train)

    predictions = model.predict(X_test)
    probabilities = model.predict_proba(X_test)[:, 1]

    report = classification_report(
        y_test, predictions, target_names=["Legitimate", "Fraud"],
        output_dict=True, zero_division=0
    )
    metrics = {
        "dataset": "synthetic educational demo",
        "test_rows": int(len(y_test)),
        "fraud_rows_in_test": int((y_test == 1).sum()),
        "roc_auc": float(roc_auc_score(y_test, probabilities)),
        "classification_report": report,
        "confusion_matrix": confusion_matrix(y_test, predictions).tolist()
    }

    with open(OUTPUT_DIR / "metrics.json", "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)

    fig, ax = plt.subplots(figsize=(6, 5))
    ConfusionMatrixDisplay.from_predictions(
        y_test, predictions,
        display_labels=["Legitimate", "Fraud"],
        cmap="Blues", ax=ax, colorbar=False
    )
    ax.set_title("Fraud Detection - Confusion Matrix (Demo Data)")
    fig.tight_layout()
    fig.savefig(OUTPUT_DIR / "confusion_matrix.png", dpi=150)
    plt.close(fig)

    importances = pd.Series(model.feature_importances_, index=X.columns)
    importances.sort_values().plot(kind="barh", figsize=(8, 5))
    plt.title("Feature Importance (Demo Model)")
    plt.xlabel("Importance")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "feature_importance.png", dpi=150)
    plt.close()

    joblib.dump({"model": model, "columns": list(X.columns)}, MODEL_PATH)

    print("\n=== CREDIT CARD FRAUD DETECTION: DEMO RESULTS ===")
    print(classification_report(
        y_test, predictions, target_names=["Legitimate", "Fraud"],
        zero_division=0
    ))
    print(f"ROC-AUC: {metrics['roc_auc']:.3f}")
    print(f"\nSaved model: {MODEL_PATH}")
    print(f"Saved results and charts in: {OUTPUT_DIR}")
    print("\nReminder: synthetic demo results are not real-world performance.")


if __name__ == "__main__":
    main()
